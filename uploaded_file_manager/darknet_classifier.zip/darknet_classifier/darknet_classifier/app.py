from flask import Flask, request, render_template, jsonify
import pickle
import pandas as pd

app = Flask(__name__)

# Load the model
with open("web_traffic_model.pkl", "rb") as file:
    model = pickle.load(file)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    url = request.form["url"]
    input_df = pd.DataFrame([url], columns=["url"])
    
    try:
        prediction = model.predict(input_df)[0]
        result = "No Threat" if prediction == 1 else "Threat"
    except Exception as e:
        result = f"Error: {e}"

    return jsonify({"url": url, "result": result})

if __name__ == "__main__":
    app.run(debug=True)