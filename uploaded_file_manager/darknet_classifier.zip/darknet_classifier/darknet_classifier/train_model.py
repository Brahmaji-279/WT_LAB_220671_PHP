# -*- coding: utf-8 -*-
"""
Created on Fri Jun 20 13:44:31 2025

@author: DELL
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report, confusion_matrix
import pickle
import matplotlib.pyplot as plt
import seaborn as sns
import os

# Load the dataset
data_path = "C:\\Users\\DELL\\OneDrive\\Documents\\Web_Dataset.csv"
df = pd.read_csv(data_path)

# Preview data
print("Sample Data:\n", df.head())

# Ensure required columns exist
assert 'Url' in df.columns, "Missing 'Url' column"
assert 'Label' in df.columns, "Missing 'Label' column"

# Drop rows with missing values (optional, if needed)
df.dropna(subset=['Url', 'Label'], inplace=True)

# Define features and target
X = df['Url']
y = df['Label']  # 0 = Threat, 1 = No Threat

# Split into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

# Build the pipeline
pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(stop_words='english')),
    ('clf', RandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced'))
])

# Train the model
pipeline.fit(X_train, y_train)

# Make predictions
y_pred = pipeline.predict(X_test)

# Evaluation
print("\nClassification Report:\n")
print(classification_report(y_test, y_pred))

# Confusion Matrix
conf_matrix = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(6, 4))
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues')
plt.title("Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.tight_layout()
plt.show()

# Save the model
output_path = "C:\\Users\\DELL\\Downloads\\darknet_classifier\\web_traffic_model.pkl"
with open(output_path, "wb") as file:
    pickle.dump(pipeline, file)

print(f"\n✅ Model saved successfully at: {output_path}")
