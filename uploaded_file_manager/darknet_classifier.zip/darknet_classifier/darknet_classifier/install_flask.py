import pip._internal
pip._internal.main(['install', 'flask-3.1.1-py3-none-any.whl'])
