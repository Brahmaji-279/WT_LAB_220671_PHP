import pandas as pd
import numpy as np
import os
import re
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
import torch.optim as optim
from collections import Counter

# Device setup
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Parameters
MAX_LEN = 100
BATCH_SIZE = 32
EMBEDDING_DIM = 100
NUM_EPOCHS = 10
MODEL_PATH = "textcnn_model.pth"

# Load dataset
df = pd.read_csv("Web_Dataset.csv")
df = df[['Url', 'Label']].dropna()

# Clean URL
def clean_url(url):
    url = url.lower()
    url = re.sub(r'[^\w\s]', '', url)
    return url

df['Url'] = df['Url'].apply(clean_url)

# Build vocabulary
all_text = " ".join(df['Url']).split()
vocab_list = ["<PAD>", "<UNK>"] + [word for word, _ in Counter(all_text).most_common()]
word2idx = {word: idx for idx, word in enumerate(vocab_list)}

def encode(text):
    tokens = text.split()
    idxs = [word2idx.get(token, word2idx["<UNK>"]) for token in tokens]
    if len(idxs) < MAX_LEN:
        idxs += [word2idx["<PAD>"]] * (MAX_LEN - len(idxs))
    else:
        idxs = idxs[:MAX_LEN]
    return idxs

df['encoded'] = df['Url'].apply(encode)

# Dataset class
class URLDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.tensor(X, dtype=torch.long)
        self.y = torch.tensor(y.values, dtype=torch.long)

    def __len__(self): return len(self.X)
    def __getitem__(self, idx): return self.X[idx], self.y[idx]

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    df['encoded'].tolist(), df['Label'], test_size=0.2, stratify=df['Label'], random_state=42
)

train_loader = DataLoader(URLDataset(X_train, y_train), batch_size=BATCH_SIZE, shuffle=True)

# TextCNN Model
class TextCNN(nn.Module):
    def __init__(self, vocab_size, embed_dim, num_classes=2):
        super(TextCNN, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=word2idx["<PAD>"])
        self.conv1 = nn.Conv1d(embed_dim, 100, kernel_size=3)
        self.relu = nn.ReLU()
        self.pool = nn.AdaptiveMaxPool1d(1)
        self.fc = nn.Linear(100, num_classes)

    def forward(self, x):
        x = self.embedding(x).permute(0, 2, 1)
        x = self.pool(self.relu(self.conv1(x))).squeeze(2)
        return self.fc(x)

# Model init
model = TextCNN(len(word2idx), EMBEDDING_DIM).to(device)
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# Training loop
for epoch in range(NUM_EPOCHS):
    model.train()
    total_loss = 0
    for X_batch, y_batch in train_loader:
        X_batch, y_batch = X_batch.to(device), y_batch.to(device)
        optimizer.zero_grad()
        outputs = model(X_batch)
        loss = criterion(outputs, y_batch)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
    print(f"Epoch {epoch+1}/{NUM_EPOCHS} Loss: {total_loss:.4f}")

# Save model and vocab
torch.save({
    'model_state_dict': model.state_dict(),
    'vocab': word2idx,
    'max_len': MAX_LEN
}, os.path.join("C:/Users/DELL/Downloads/darknet_classifier", MODEL_PATH))

print(f"\n✅ TextCNN model saved successfully at: {MODEL_PATH}")
