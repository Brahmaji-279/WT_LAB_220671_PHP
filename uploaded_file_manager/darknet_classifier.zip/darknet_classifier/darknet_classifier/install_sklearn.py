import subprocess
import sys

try:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "scikit-learn"])
    print("✅ scikit-learn installed successfully.")
except Exception as e:
    print("❌ Installation failed:", e)

input("\nPress Enter to close this window...")
