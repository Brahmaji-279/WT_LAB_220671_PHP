import torch
import torch.nn as nn
from train_textcnn import TextCNN, vocab, max_len  # Import your model class and vocab
import torch.nn.functional as F

# Load trained model
model = TextCNN(len(vocab))
model.load_state_dict(torch.load("textcnn_model.pth"))
model.eval()

# Tokenization helper
def encode_url(url):
    tokens = [vocab.get(char, vocab['<UNK>']) for char in url]
    if len(tokens) < max_len:
        tokens += [vocab['<PAD>']] * (max_len - len(tokens))
    else:
        tokens = tokens[:max_len]
    return torch.tensor([tokens])

# Prediction function
def predict_url(url):
    with torch.no_grad():
        inputs = encode_url(url)
        outputs = model(inputs)
        probs = F.softmax(outputs, dim=1)
        predicted = torch.argmax(probs, dim=1).item()
        return predicted, probs.numpy().tolist()

# Example
url = "darkmarketxyz.onion"
label, confidence = predict_url(url)
print(f"URL: {url}")
print("Prediction:", "No Threat" if label == 1 else "Threat")
print("Confidence:", confidence)
