from flask import Flask, request, jsonify, render_template
import torch
import torch.nn as nn
import re
import pickle

app = Flask(__name__)
MODEL_PATH = "textcnn_model.pth"

# Load model and vocab
checkpoint = torch.load(MODEL_PATH, map_location=torch.device("cpu"))
vocab = checkpoint['vocab']

class TextCNN(nn.Module):
    def __init__(self, vocab_size, embed_dim=100, num_classes=2):
        super(TextCNN, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        self.conv1 = nn.Conv1d(embed_dim, 100, kernel_size=3)
        self.relu = nn.ReLU()
        self.pool = nn.AdaptiveMaxPool1d(1)
        self.fc = nn.Linear(100, num_classes)
    def forward(self, x):
        x = self.embedding(x).permute(0, 2, 1)
        x = self.pool(self.relu(self.conv1(x))).squeeze(2)
        return self.fc(x)

model = TextCNN(len(vocab))
model.load_state_dict(checkpoint['model_state_dict'])
model.eval()

def clean_url(url):
    url = url.lower()
    url = re.sub(r'[^\w\s]', '', url)
    return url

def encode(url):
    tokens = clean_url(url).split()
    idxs = [vocab.get(word, vocab["<UNK>"]) for word in tokens]
    idxs = idxs[:100] + [0]*(100 - len(idxs))
    return torch.tensor([idxs])

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    url = request.form["url"]
    input_tensor = encode(url)
    with torch.no_grad():
        output = model(input_tensor)
        prediction = torch.argmax(output, dim=1).item()
    result = "No Threat" if prediction == 1 else "Threat"
    return jsonify({"url": url, "result": result})

if __name__ == "__main__":
    app.run(debug=True)
